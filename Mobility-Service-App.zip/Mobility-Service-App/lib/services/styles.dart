import 'package:flutter/material.dart';

const white = Colors.white;
const blue = Colors.blue;
const red = Colors.red;
const yellow = Colors.yellow;
const green = Colors.green;
const black = Colors.black;
const grey = Colors.grey;