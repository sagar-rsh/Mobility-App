class Place{
  String place;
  String image;
  int days;

  Place({this.place, this.image, this.days});

}