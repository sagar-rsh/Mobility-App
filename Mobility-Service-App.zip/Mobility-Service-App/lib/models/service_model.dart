class Service {
  final String name;
  final String price;
  final String service;

  Service({this.name, this.price, this.service});
}
